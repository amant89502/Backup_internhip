def google_logo():
    return "//img[@id='hplogo']"
def google_search_text_box():
    return "//input[@name='q']"



