def google_logo(): return "//img[@alt='Google']"
def google_search_text_box(): return "//input[@name='q']"
