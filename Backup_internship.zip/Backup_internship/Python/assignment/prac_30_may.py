# list1 = ['a','b', 'c', 'd', 'e', 'f', 'g', 'h', 'i']
# list2 = [ 0,  1,  1, 0,  1, 2, 2,  0,  1]
# list4=sorted(list2)
# print(list4)
#
# list3=[]
# for i in list1:
#     for j in list4:
#         list1[i]=list2[j]

#Actual code starts from here..

# list1 = ["a", "b", "c", "d", "e", "f", "g", "h", "i"]
# list2 = [0, 1, 1, 0, 1, 2, 2, 0, 1]
# list3=[]
#
# sorted_list = sorted(zip(list2, list1))
# print(sorted_list)
# # print(sorted_list[1][1])
# for j in range(len(sorted_list)):
#     list3.append(sorted_list[j][1])
# print(list3)
    # reverse the number

# n = 76542
# reversed_n = str(n)[::-1]
# print(reversed_n)
# a=str(n)
# print(a)










