import time
import sys
sys.path.append('C:/Users/158173/OneDrive - Arrow Electronics, Inc/Desktop/pytest_practice')
from selenium import webdriver
import pytest
from selenium.webdriver.chrome.service import Service as Service
from webdriver_manager.chrome import ChromeDriverManager
from selenium.webdriver.common.by import By
from selenium.webdriver.common.action_chains import ActionChains

def test_amazon_logo():
    global webdriver
    driver = webdriver.Chrome()
    driver.get("https://www.amazon.in/")
    driver.maximize_window()
    driver.implicitly_wait(10)
    logo=driver.find_elements(By.XPATH, "//a[@id='nav-logo-sprites']")
    assert len(logo) > 0
    driver.quit()

@pytest.mark.aman
def test_amazon_textbox():
    driver = webdriver.Chrome()
    driver.get("https://www.amazon.in/")
    driver.maximize_window()
    driver.implicitly_wait(10)
    driver.find_element(By.XPATH,"//input[@id='twotabsearchtextbox']").send_keys("Mobile")
    time.sleep(2)
    driver.find_element(By.XPATH,"//div[text()='16 GB']").click()
    time.sleep(2)
    element1 = driver.find_element(By.XPATH, "//span[text()='Samsung Galaxy S21 FE 8GB 128GB (Graphite)']")
    ActionChains(driver).move_to_element(element1).perform()
    time.sleep(2)
    driver.find_element(By.XPATH,"//span[text()='Samsung Galaxy S21 FE 8GB 128GB (Graphite)']").click()
    time.sleep(4)
    driver.quit()

@pytest.mark.tiwari
def test_amazon_sidebar():
    driver = webdriver.Chrome()
    driver.get("https://www.amazon.in/")
    driver.maximize_window()
    driver.implicitly_wait(10)
    driver.find_element(By.XPATH,"//a[@id='nav-hamburger-menu']").click()
    time.sleep(3)
    a=driver.find_element(By.XPATH,"//a[@id='nav-hamburger-menu']").text
    print(a)
    driver.quit()




